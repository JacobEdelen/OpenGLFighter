typedef float_t float;


typedef struct 
{
	float_t x;
	float_t y;
} position_t;
